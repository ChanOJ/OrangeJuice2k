btnnecta.gif => Nectarine radio => link to http://nectarine.ojuice.net
btnoj2.gif => Orange Juice web => link to http://www.ojuice.net